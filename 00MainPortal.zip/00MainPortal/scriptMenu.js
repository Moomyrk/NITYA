'use strict';
let button = document.querySelector('#button');
let menu = document.querySelector('#menu');
let overlay = document.querySelector('#overlay');

button.addEventListener('click', (e) => {
    e.preventDefault();
    menu.classList.add('active');
    overlay.classList.add('active');
}
);

overlay.addEventListener('click', () => {
    menu.classList.remove('active');
    overlay.classList.remove('active');
});
