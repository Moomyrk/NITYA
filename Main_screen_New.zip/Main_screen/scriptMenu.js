'use strict';
let button = document.querySelector('#button');
let menu = document.querySelector('#menu');
let overlay = document.querySelector('#overlay');

button.addEventListener('click', (e) => {
    e.preventDefault();
    menu.classList.add('active');
    overlay.classList.add('active');
}
);

overlay.addEventListener('click', () => {
    menu.classList.remove('active');
    overlay.classList.remove('active');
});

/*
function openMenu() {
    document.getElementById("dropUp").classList.toggle("show");
};

window.onclick = function (event) {
    if (!event.target.matches('.menuButton')) {
        let dropdowns = document.getElementsByClassName("menuContent");
        let i;
        for (i = 0; i < dropdowns.length; i++) {
            let openDropdown = dropdowns[i];
            if (openDropdown.classList.contains('show')) {
                openDropdown.classList.remove('show');
            };
        };
    };
};
*/